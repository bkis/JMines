package idh.java.jmines.ui.gui;

import idh.java.jmines.ui.JMinesUi;
import idh.java.jmines.ui.UiCallback;

/**
 * This is an implementation of the JMinesUi interface.
 * It offers a graphical user interface to play the JMines game.
 */
public class JMinesGui implements JMinesUi {
	
	//UI callbacks for interaction with game core
	private UiCallback reveal;
	private UiCallback mark;
	private UiCallback newGame;
	
	@Override
	public void registerRevealCallback(UiCallback callback) {
		reveal = callback; //reference to callback as a field
	}

	@Override
	public void registerMarkCallback(UiCallback callback) {
		mark = callback; //reference to callback as a field
	}

	@Override
	public void registerNewGameCallback(UiCallback callback) {
		newGame = callback; //reference to callback as a field
	}

}
