package idh.java.callbacks;

public interface Callback {
	
	public void call(int foo);

}
