package idh.java.callbacks;

public class Main {

	public static void main(String[] args) {
		new Chief(); // look @ constructor of Chief!
	}

}
