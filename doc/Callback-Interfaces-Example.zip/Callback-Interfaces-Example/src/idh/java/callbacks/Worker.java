package idh.java.callbacks;

public class Worker {
	
	private Callback callback;
	
	// ability of the worker to learn how to call back
	public void registerCallback(Callback c) {
		callback = c;
	}
	
	public void work(int i) {
		System.out.println("Worker: I'm working on that addition " + i + " + 1 ...");
		
		try {
			Thread.sleep(2000);
		} catch (Exception e) {
			// Pokémon Exception Handling!
		}
		
		i++; // work
		
		System.out.println("Worker: Ah! I got it! Let's call back the chief to report the result ...");
		callback.call(i); // calling back
	}

}
