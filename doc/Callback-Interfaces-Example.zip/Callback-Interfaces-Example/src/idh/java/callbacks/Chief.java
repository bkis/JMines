package idh.java.callbacks;

public class Chief {
	
	public Chief() {
		
		System.out.println("Chief: I will hire a new worker, "
				+ "they should add 1 to a number and report back!");
		
		// create new worker
		Worker worker = new Worker();
		
		// tell worker how to report back
		worker.registerCallback(new Callback() {
			@Override
			public void call(int foo) {
				callbackMethod(foo);
			}
		});
		
		// give job to worker
		System.out.println("Chief: Hey, worker, add 1 to 42 and report back once you're done!");
		worker.work(42);
	}
	
	private void callbackMethod(int x) {
		// tell us the result the worker reported back with
		System.out.println("Chief: Worker says the number is now " + x + ".");
	}

}
