package idh.java.jmines.ui;

/**
 * This interface defines the methods needed in a
 * MineSweeper user interface. The methods to register
 * all the UI callbacks is all there is. That's it.
 */
public interface JMinesUi {
	
	//methods to register callbacks received from the game core
	public void registerRevealCallback(UiCallback callback);
	public void registerMarkCallback(UiCallback callback);
	public void registerNewGameCallback(UiCallback callback);

}
