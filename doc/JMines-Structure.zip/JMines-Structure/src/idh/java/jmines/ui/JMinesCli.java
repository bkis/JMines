package idh.java.jmines.ui;

/**
 * This is an implementation of the MineSweeperUi interface.
 * It offer a command line interface to play the MineSweeper game.
 */
public class JMinesCli implements JMinesUi {
	
	//UI callbacks for interaction with game core
	private UiCallback reveal;
	private UiCallback mark;
	private UiCallback newGame;
	
	@Override
	public void registerRevealCallback(UiCallback callback) {
		reveal = callback; //reference to callback as a field
	}

	@Override
	public void registerMarkCallback(UiCallback callback) {
		mark = callback; //reference to callback as a field
	}

	@Override
	public void registerNewGameCallback(UiCallback callback) {
		newGame = callback; //reference to callback as a field
	}

}
