package idh.java.jmines;

import idh.java.jmines.ui.JMinesCli;
import idh.java.jmines.ui.JMinesUi;
import idh.java.jmines.ui.UiCallback;

public class JMines {
	
	private JMinesUi ui; //a reference to the user interface
	private GameState state; //a reference to the current game state
	
	/**
	 * This constructor initializes the MineSweeper game
	 */
	public JMines() {
		//initialize the user interface (could also be a GUI!)
		ui = new JMinesCli(); //use CLI for now
		
		//register reveal callback
		ui.registerRevealCallback(new UiCallback() {
			@Override
			public GameState call(int x, int y) {
				return reveal(x, y); //actual method call here
			}
		});
		
		//register mark callback
		ui.registerMarkCallback(new UiCallback() {
			@Override
			public GameState call(int x, int y) {
				return mark(x, y); //actual method call here
			}
		});
		
		//register new game callback
		ui.registerNewGameCallback(new UiCallback() {
			@Override
			public GameState call(int x, int y) {
				return newGame(x, y); //actual method call here
			}
		});
	}
	
	//reveal a cell!
	private GameState reveal(int x, int y) {
		//TODO: implement reveal logic
		return state;
	}
	
	//mark a cell!
	private GameState mark(int x, int y) {
		//TODO: implement mark logic
		return state;
	}
	
	//start a new game!
	private GameState newGame(int dimensions, int difficulty) {
		//TODO: implement "start new game" logic
		return state;
	}

}
