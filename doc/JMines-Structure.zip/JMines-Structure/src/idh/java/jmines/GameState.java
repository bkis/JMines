package idh.java.jmines;

/**
 * This class represents the MineSweeper game state.
 * It's (mainly) just a simple data class / POJO.
 */
public class GameState {
	
	private Cell[][] board; //the game board
	private int dimensions; //the game board dimensions
	private int difficulty; //the game difficulty
	private int mines; //the number of mines on the game board
	private int marked; //the number of marked cells
	private boolean won; //is the game won?
	private boolean lost; //is the game lost?
	
	
	//// CONSTRUCTOR ////
	
	public GameState(int dimensions, int difficulty) {
		super();
		this.dimensions = dimensions;
		this.difficulty = difficulty;
		initBoard();
	}
	
	
	//// SOME FUNCTIONALITY DRAFTS ////
	
	private void initBoard() {
		board = new Cell[dimensions][dimensions]; //initialize board object
		calcMineCount(); //calculate number of mines to deploy
		//TODO: initialize / fill game board
	}
	
	private int calcMineCount() {
		//TODO: an algorithm that calculates the number of mines
		//      for the specified dimensions & difficulty
		return 0;
	}
	
}
